##
 #  Copyright (c) 2006, FlexiGuided GmbH, Berlin, Germany
 #  Author: Jan Behrens <jan.behrens@flexiguided.de>
 #  All rights reserved.
 #
 #  Redistribution and use in source and binary forms, with or without
 #  modification, are permitted provided that the following conditions are
 #  met:
 #
 #  1. Redistributions of source code must retain the above copyright
 #     notice, this list of conditions and the following disclaimer.
 #  2. Redistributions in binary form must reproduce the above copyright
 #     notice, this list of conditions and the following disclaimer in the
 #     documentation and/or other materials provided with the distribution.
 #  3. Neither the name of the FlexiGuided GmbH nor the names of its
 #     contributors may be used to endorse or promote products derived from
 #     this software without specific prior written permission.
 #
 #  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 #  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 #  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 #  PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 #  OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 #  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 #  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 #  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 #  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 #  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 #  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 #
 ##
 

##
 #  File name:    ruby/utf8proc.rb
 #  Version:      0.2
 #  Last changed: 2006-05-31
 #
 #  Description:
 #  Part of the ruby wrapper for libutf8proc, which is written in ruby.
 ##


require 'utf8proc_native'

module Utf8Proc
  SpecialChars = {
    :HT => "\x09",
    :LF => "\x0A",
    :VT => "\x0B",
    :FF => "\x0C",
    :CR => "\x0D",
    :FS => "\x1C",
    :GS => "\x1D",
    :RS => "\x1E",
    :US => "\x1F",
    :LS => "\xE2\x80\xA8",
    :PS => "\xE2\x80\xA9",
  }
end

class String
  def utf8map(*option_array)
    options = 0
    option_array.each do |option|
      flag = Utf8Proc::Options[option]
      raise ArgumentError, "Unknown argument given to String#utf8map." unless
        flag
      options |= flag
    end
    return Utf8Proc::utf8map(self, options)
  end
  def utf8map!(*option_array)
    self.replace(self.utf8map(*option_array))
  end
  def utf8nfd;   utf8map( :stable); end
  def utf8nfd!;  utf8map!(:stable); end
  def utf8nfc;   utf8map( :stable, :compose); end
  def utf8nfc!;  utf8map!(:stable, :compose); end
  def utf8nfkd;  utf8map( :stable, :compat); end
  def utf8nfkd!; utf8map!(:stable, :compat); end
  def utf8nfkc;  utf8map( :stable, :compose, :compat); end
  def utf8nfkc!; utf8map!(:stable, :compose, :compat); end
end

class Integer
  def utf8
    return Utf8Proc::utf8char(self)
  end
end


