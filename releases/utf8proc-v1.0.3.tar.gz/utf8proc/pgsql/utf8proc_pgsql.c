/*
 *  Copyright (c) 2006, FlexiGuided GmbH, Berlin, Germany
 *  Author: Jan Behrens <jan.behrens@flexiguided.de>
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are
 *  met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of the FlexiGuided GmbH nor the names of its
 *     contributors may be used to endorse or promote products derived from
 *     this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 *  PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 *  OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 *  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 *  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 *  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 *  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
 

/*
 *  File name:    pgsql/utf8proc_pgsql.c
 *  Version:      1.0
 *  Last changed: 2006-09-17
 *
 *  Description:
 *  PostgreSQL extension to provide a function 'unifold', which can be used
 *  to case-fold and normalize index fields.
 */


#include "../utf8proc.c"

#include <postgres.h>
#include <utils/elog.h>
#include <fmgr.h>
#include <string.h>
#include <unistd.h>
#include <utils/builtins.h>

#ifdef PG_MODULE_MAGIC
PG_MODULE_MAGIC;
#endif

#define UTF8PROC_PGSQL_OPTS ( UTF8PROC_REJECTNA | UTF8PROC_COMPAT | \
  UTF8PROC_COMPOSE | UTF8PROC_STABLE | UTF8PROC_IGNORE | UTF8PROC_STRIPCC | \
  UTF8PROC_NLF2LF | UTF8PROC_CASEFOLD | UTF8PROC_LUMP )

PG_FUNCTION_INFO_V1(utf8proc_pgsql_unifold);
Datum utf8proc_pgsql_unifold(PG_FUNCTION_ARGS) {
  text *input_string;
  text *output_string = NULL;
  ssize_t result;
  input_string = PG_GETARG_TEXT_P(0);
  do {
    result = utf8proc_decompose(
      VARDATA(input_string), VARSIZE(input_string) - VARHDRSZ,
      NULL, 0, UTF8PROC_PGSQL_OPTS
    );
    if (result < 0) break;
    if (result > (SIZE_MAX-1-VARHDRSZ)/sizeof(int32_t)) {
      result = UTF8PROC_ERROR_OVERFLOW;
      break;
    }
    output_string = palloc(result * sizeof(int32_t) + 1 + VARHDRSZ);
    // reserve one extra byte for termination
    if (!output_string) {
      result = UTF8PROC_ERROR_NOMEM;
      break;
    }
    result = utf8proc_decompose(
      VARDATA(input_string), VARSIZE(input_string) - VARHDRSZ,
      (int32_t *)VARDATA(output_string), result, UTF8PROC_PGSQL_OPTS);
    if (result < 0) break;
    result = utf8proc_reencode((int32_t *)VARDATA(output_string), result,
      UTF8PROC_PGSQL_OPTS);
  } while (0);
  PG_FREE_IF_COPY(input_string, 0);
  if (result < 0) {
    int sqlerrcode;
    if (output_string) pfree(output_string);
    switch(result) {
      case UTF8PROC_ERROR_NOMEM:
      sqlerrcode = ERRCODE_OUT_OF_MEMORY; break;
      case UTF8PROC_ERROR_OVERFLOW:
      sqlerrcode = ERRCODE_PROGRAM_LIMIT_EXCEEDED; break;
      case UTF8PROC_ERROR_INVALIDUTF8:
      case UTF8PROC_ERROR_NOTASSIGNED:
      PG_RETURN_NULL();
      default:
      sqlerrcode = ERRCODE_INTERNAL_ERROR;
    }
    ereport(ERROR, (
      errcode(sqlerrcode),
      errmsg("%s", utf8proc_errmsg(result))
    ));
  } else {
    VARATT_SIZEP(output_string) = result + VARHDRSZ;
    PG_RETURN_TEXT_P(output_string);
  }
  PG_RETURN_NULL();  // prohibit compiler warning
}


