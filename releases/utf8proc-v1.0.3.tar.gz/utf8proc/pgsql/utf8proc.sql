CREATE OR REPLACE FUNCTION unifold (text) RETURNS text
  LANGUAGE 'C' IMMUTABLE STRICT AS '$libdir/utf8proc_pgsql.so',
  'utf8proc_pgsql_unifold';

