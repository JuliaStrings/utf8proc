/*
 *  Copyright (c) 2006, FlexiGuided GmbH, Berlin, Germany
 *  Author: Jan Behrens <jan.behrens@flexiguided.de>
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are
 *  met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of the FlexiGuided GmbH nor the names of its
 *     contributors may be used to endorse or promote products derived from
 *     this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 *  PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 *  OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 *  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 *  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 *  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 *  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
 

/*
 *  File name:    pgsql/utf8proc_pgsql.c
 *  Version:      0.1
 *  Last changed: 2006-05-31
 *
 *  Description:
 *  PostgreSQL extension to provide a function 'unifold', which can be used
 *  to case-fold and normalize index fields.
 */


#include "../utf8proc.c"

#include <postgres.h>
#include <utils/elog.h>
#include <fmgr.h>
#include <unistd.h>
#include <string.h>
#include <utils/builtins.h>

PG_FUNCTION_INFO_V1(utf8proc_pgsql_unifold);

Datum utf8proc_pgsql_unifold(PG_FUNCTION_ARGS) {
  char *input_string;
  uint8_t *output_string;
  ssize_t result;
  input_string = DatumGetCString(
    DirectFunctionCall1(textout, PG_GETARG_DATUM(0))
  );
  result = utf8proc_map(input_string, 0, &output_string, UTF8PROC_NULLTERM |
    UTF8PROC_COMPOSE | UTF8PROC_IGNORE | UTF8PROC_STRIPCC | UTF8PROC_CASEFOLD);
  pfree(input_string);
  if (result < 0) {
    int sqlerrcode;
    switch(result) {
      case UTF8PROC_ERROR_NOMEM:
      sqlerrcode = ERRCODE_OUT_OF_MEMORY; break;
      case UTF8PROC_ERROR_OVERFLOW:
      sqlerrcode = ERRCODE_PROGRAM_LIMIT_EXCEEDED; break;
      case UTF8PROC_ERROR_INVALIDUTF8:
      case UTF8PROC_ERROR_NOTASSIGNED:
      sqlerrcode = ERRCODE_DATA_EXCEPTION; break;
      default:
      sqlerrcode = ERRCODE_INTERNAL_ERROR;
    }
    ereport(ERROR, (
      errcode(sqlerrcode),
      errmsg("%s", utf8proc_errmsg(result))
    ));
  }
  {
    Datum retval;
    retval = DirectFunctionCall1(textin, CStringGetDatum(output_string));
    free(output_string);
    PG_RETURN_TEXT_P(DatumGetTextP(retval));
  }
}


