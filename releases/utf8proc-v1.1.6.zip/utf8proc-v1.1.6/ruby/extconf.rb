require 'mkmf'
create_makefile("utf8proc_native")
